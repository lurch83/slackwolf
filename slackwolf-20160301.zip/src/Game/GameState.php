<?php namespace Slackwolf\Game;

class GameState
{
    const LOBBY = 0;
    const FIRST_NIGHT = 1;
    const DAY = 2;
    const NIGHT = 3;
    const OVER = 9;
}