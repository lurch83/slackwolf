<?php namespace Slackwolf\Game;

class Role
{
    const VILLAGER = "Villager";
    const SEER = "Seer";
    const WEREWOLF = "Werewolf";
    const BODYGUARD = "Bodyguard";
    const TANNER = "Tanner";
    const LYCAN = "Lycan";
    const BEHOLDER = "Beholder";
    const MINION = "Minion";
    //const WOLF_MAN = "Wolfman"; /*  Opposite of Lycan */
}
